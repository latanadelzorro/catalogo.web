// Variables globales
let movimientos = [];
let mesActual = new Date().getMonth();
let añoActual = new Date().getFullYear();

// Elementos del DOM
const formMovimiento = document.getElementById('form-movimiento');
const listaMovimientos = document.getElementById('lista-movimientos');
const totalIngresos = document.getElementById('total-ingresos');
const totalGastos = document.getElementById('total-gastos');
const balanceTotal = document.getElementById('balance-total');
const mesActualElement = document.getElementById('mes-actual');
const btnMesAnterior = document.getElementById('prev-month');
const btnMesSiguiente = document.getElementById('next-month');
const filtroTipo = document.getElementById('filtro-tipo');
const filtroCategoria = document.getElementById('filtro-categoria');

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
    cargarMovimientos();
    actualizarFecha();
    actualizarResumen();
    actualizarGraficos();
    configurarEventListeners();
});

// Configurar event listeners
function configurarEventListeners() {
    // Guardar movimiento
    formMovimiento.addEventListener('submit', manejarEnvioFormulario);
    
    // Navegación entre meses
    btnMesAnterior.addEventListener('click', () => cambiarMes(-1));
    btnMesSiguiente.addEventListener('click', () => cambiarMes(1));
    
    // Filtros
    filtroTipo.addEventListener('change', filtrarMovimientos);
    filtroCategoria.addEventListener('change', filtrarMovimientos);
}

// Manejar el envío del formulario
function manejarEnvioFormulario(e) {
    e.preventDefault();
    
    const tipo = document.getElementById('tipo').value;
    const categoria = document.getElementById('categoria').value;
    const descripcion = document.getElementById('descripcion').value.trim();
    const monto = parseFloat(document.getElementById('monto').value);
    const fecha = document.getElementById('fecha').value;
    
    if (!descripcion || isNaN(monto) || monto <= 0 || !fecha) {
        mostrarNotificacion('Por favor, complete todos los campos correctamente', 'error');
        return;
    }
    
    const movimiento = {
        id: Date.now(),
        tipo,
        categoria,
        descripcion,
        monto,
        fecha: new Date(fecha).toISOString()
    };
    
    // Agregar a la lista de movimientos
    movimientos.push(movimiento);
    guardarMovimientos();
    
    // Actualizar la interfaz
    if (esMovimientoDelMesActual(movimiento.fecha)) {
        mostrarMovimiento(movimiento);
        actualizarResumen();
        actualizarGraficos();
    }
    
    // Reiniciar el formulario
    formMovimiento.reset();
    document.getElementById('fecha').value = new Date().toISOString().split('T')[0];
    
    mostrarNotificacion('Movimiento guardado correctamente', 'exito');
}

// Mostrar un movimiento en la lista
function mostrarMovimiento(movimiento) {
    const movimientoElement = document.createElement('div');
    movimientoElement.className = `movimiento ${movimiento.tipo}`;
    movimientoElement.dataset.id = movimiento.id;
    
    const esIngreso = movimiento.tipo === 'ingreso';
    const icono = esIngreso ? 'arrow-up' : 'arrow-down';
    const signo = esIngreso ? '+' : '-';
    
    movimientoElement.innerHTML = `
        <div class="movimiento-info">
            <div class="movimiento-categoria">${formatearCategoria(movimiento.categoria)}</div>
            <div class="movimiento-descripcion">${movimiento.descripcion}</div>
            <div class="movimiento-fecha">${formatearFecha(movimiento.fecha)}</div>
        </div>
        <div class="movimiento-monto">${signo}€${movimiento.monto.toFixed(2)}</div>
        <div class="movimiento-acciones">
            <button class="btn-accion btn-eliminar" data-id="${movimiento.id}">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    // Agregar a la lista
    const sinMovimientos = document.querySelector('.sin-movimientos');
    if (sinMovimientos) {
        listaMovimientos.innerHTML = '';
    }
    
    listaMovimientos.prepend(movimientoElement);
    
    // Agregar evento de eliminación
    const btnEliminar = movimientoElement.querySelector('.btn-eliminar');
    btnEliminar.addEventListener('click', () => eliminarMovimiento(movimiento.id));
}

// Actualizar el resumen financiero
function actualizarResumen() {
    const movimientosMes = obtenerMovimientosDelMes();
    
    const ingresos = movimientosMes
        .filter(m => m.tipo === 'ingreso')
        .reduce((total, m) => total + m.monto, 0);
    
    const gastos = movimientosMes
        .filter(m => m.tipo === 'gasto')
        .reduce((total, m) => total + m.monto, 0);
    
    const balance = ingresos - gastos;
    
    // Actualizar la interfaz
    totalIngresos.textContent = `€${ingresos.toFixed(2)}`;
    totalGastos.textContent = `€${gastos.toFixed(2)}`;
    balanceTotal.textContent = `€${balance.toFixed(2)}`;
    
    // Actualizar variación
    actualizarVariacion(ingresos, gastos, balance);
}

// Actualizar gráficos
function actualizarGraficos() {
    const movimientosMes = obtenerMovimientosDelMes();
    
    // Gráfico de pastel de gastos
    const gastosPorCategoria = {};
    movimientosMes
        .filter(m => m.tipo === 'gasto')
        .forEach(m => {
            gastosPorCategoria[m.categoria] = (gastosPorCategoria[m.categoria] || 0) + m.monto;
        });
    
    const ctxPastel = document.getElementById('grafico-gastos').getContext('2d');
    
    // Destruir gráfico anterior si existe
    if (window.graficoPastel) {
        window.graficoPastel.destroy();
    }
    
    if (Object.keys(gastosPorCategoria).length > 0) {
        window.graficoPastel = new Chart(ctxPastel, {
            type: 'pie',
            data: {
                labels: Object.keys(gastosPorCategoria).map(formatearCategoria),
                datasets: [{
                    data: Object.values(gastosPorCategoria),
                    backgroundColor: [
                        '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
                        '#FF9F40', '#8AC24A', '#F06292', '#7986CB', '#4DB6AC'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: €${value.toFixed(2)} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    } else {
        // Mostrar mensaje si no hay datos
        ctxPastel.textAlign = 'center';
        ctxPastel.textBaseline = 'middle';
        ctxPastel.fillStyle = '#999';
        ctxPastel.font = '16px Montserrat';
        ctxPastel.fillText('No hay datos de gastos', ctxPastel.canvas.width / 2, ctxPastel.canvas.height / 2);
    }
    
    // Gráfico de evolución mensual (últimos 6 meses)
    const ultimosMeses = [];
    const ingresosMensuales = [];
    const gastosMensuales = [];
    
    for (let i = 5; i >= 0; i--) {
        const fecha = new Date(añoActual, mesActual - i, 1);
        const mes = fecha.toLocaleString('es-ES', { month: 'short' });
        const año = fecha.getFullYear();
        ultimosMeses.push(`${mes} ${año}`);
        
        const movsMes = movimientos.filter(m => {
            const fechaMov = new Date(m.fecha);
            return fechaMov.getMonth() === fecha.getMonth() && 
                   fechaMov.getFullYear() === fecha.getFullYear();
        });
        
        ingresosMensuales.push(
            movsMes
                .filter(m => m.tipo === 'ingreso')
                .reduce((total, m) => total + m.monto, 0)
        );
        
        gastosMensuales.push(
            movsMes
                .filter(m => m.tipo === 'gasto')
                .reduce((total, m) => total + m.monto, 0)
        );
    }
    
    const ctxLinea = document.getElementById('grafico-mensual').getContext('2d');
    
    // Destruir gráfico anterior si existe
    if (window.graficoLinea) {
        window.graficoLinea.destroy();
    }
    
    window.graficoLinea = new Chart(ctxLinea, {
        type: 'line',
        data: {
            labels: ultimosMeses,
            datasets: [
                {
                    label: 'Ingresos',
                    data: ingresosMensuales,
                    borderColor: '#27AE60',
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true
                },
                {
                    label: 'Gastos',
                    data: gastosMensuales,
                    borderColor: '#E74C3C',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '€' + value;
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': €' + context.raw.toFixed(2);
                        }
                    }
                }
            }
        }
    });
}

// Filtrar movimientos por tipo y categoría
function filtrarMovimientos() {
    const tipo = filtroTipo.value;
    const categoria = filtroCategoria.value;
    
    const movimientosFiltrados = obtenerMovimientosDelMes().filter(movimiento => {
        const coincideTipo = tipo === 'todos' || movimiento.tipo === tipo;
        const coincideCategoria = !categoria || movimiento.categoria === categoria;
        return coincideTipo && coincideCategoria;
    });
    
    // Actualizar la lista
    actualizarListaMovimientos(movimientosFiltrados);
}

// Actualizar la lista de movimientos
function actualizarListaMovimientos(movimientosMostrar) {
    listaMovimientos.innerHTML = '';
    
    if (movimientosMostrar.length === 0) {
        listaMovimientos.innerHTML = `
            <div class="sin-movimientos">
                <i class="fas fa-coins"></i>
                <p>No hay movimientos que coincidan con los filtros</p>
            </div>
        `;
        return;
    }
    
    // Ordenar por fecha (más recientes primero)
    movimientosMostrar
        .sort((a, b) => new Date(b.fecha) - new Date(a.fecha))
        .forEach(mostrarMovimiento);
}

// Eliminar un movimiento
function eliminarMovimiento(id) {
    if (confirm('¿Estás seguro de que deseas eliminar este movimiento?')) {
        movimientos = movimientos.filter(m => m.id !== id);
        guardarMovimientos();
        
        // Actualizar la interfaz
        const movimientoElement = document.querySelector(`.movimiento[data-id="${id}"]`);
        if (movimientoElement) {
            movimientoElement.remove();
        }
        
        actualizarResumen();
        actualizarGraficos();
        
        // Mostrar mensaje de "sin movimientos" si es necesario
        if (listaMovimientos.children.length === 0) {
            listaMovimientos.innerHTML = `
                <div class="sin-movimientos">
                    <i class="fas fa-coins"></i>
                    <p>No hay movimientos registrados</p>
                </div>
            `;
        }
        
        mostrarNotificacion('Movimiento eliminado', 'exito');
    }
}

// Cambiar el mes actual
function cambiarMes(cambio) {
    mesActual += cambio;
    
    // Ajustar año si es necesario
    if (mesActual < 0) {
        mesActual = 11;
        añoActual--;
    } else if (mesActual > 11) {
        mesActual = 0;
        añoActual++;
    }
    
    actualizarFecha();
    actualizarResumen();
    actualizarGraficos();
    
    // Mostrar movimientos del mes seleccionado
    const movimientosMes = obtenerMovimientosDelMes();
    actualizarListaMovimientos(movimientosMes);
}

// Actualizar la fecha mostrada
function actualizarFecha() {
    const opciones = { month: 'long', year: 'numeric' };
    const fecha = new Date(añoActual, mesActual, 1);
    mesActualElement.textContent = fecha.toLocaleDateString('es-ES', opciones).charAt(0).toUpperCase() + 
                                 fecha.toLocaleDateString('es-ES', opciones).slice(1);
}

// Obtener movimientos del mes actual
function obtenerMovimientosDelMes() {
    return movimientos.filter(movimiento => {
        const fechaMov = new Date(movimiento.fecha);
        return fechaMov.getMonth() === mesActual && 
               fechaMov.getFullYear() === añoActual;
    });
}

// Verificar si un movimiento es del mes actual
function esMovimientoDelMesActual(fechaMovimiento) {
    const fecha = new Date(fechaMovimiento);
    return fecha.getMonth() === mesActual && 
           fecha.getFullYear() === añoActual;
}

// Actualizar la variación respecto al mes anterior
function actualizarVariacion(ingresosActual, gastosActual, balanceActual) {
    // Obtener datos del mes anterior
    let mesAnterior = mesActual - 1;
    let añoAnterior = añoActual;
    
    if (mesAnterior < 0) {
        mesAnterior = 11;
        añoAnterior--;
    }
    
    const movimientosMesAnterior = movimientos.filter(movimiento => {
        const fechaMov = new Date(movimiento.fecha);
        return fechaMov.getMonth() === mesAnterior && 
               fechaMov.getFullYear() === añoAnterior;
    });
    
    const ingresosAnterior = movimientosMesAnterior
        .filter(m => m.tipo === 'ingreso')
        .reduce((total, m) => total + m.monto, 0);
    
    const gastosAnterior = movimientosMesAnterior
        .filter(m => m.tipo === 'gasto')
        .reduce((total, m) => total + m.monto, 0);
    
    const balanceAnterior = ingresosAnterior - gastosAnterior;
    
    // Calcular variaciones
    const variacionIngresos = ingresosAnterior > 0 ? 
        ((ingresosActual - ingresosAnterior) / ingresosAnterior) * 100 : 0;
    
    const variacionGastos = gastosAnterior > 0 ? 
        ((gastosActual - gastosAnterior) / gastosAnterior) * 100 : 0;
    
    const variacionBalance = balanceAnterior !== 0 ? 
        ((balanceActual - balanceAnterior) / Math.abs(balanceAnterior)) * 100 : 0;
    
    // Actualizar la interfaz
    actualizarElementoVariacion('ingresos', variacionIngresos);
    actualizarElementoVariacion('gastos', variacionGastos);
    actualizarElementoVariacion('balance', variacionBalance);
}

// Actualizar un elemento de variación
function actualizarElementoVariacion(tipo, variacion) {
    const elemento = document.getElementById(`variacion-${tipo}`);
    const icono = document.querySelector(`#variacion-${tipo}`).parentElement.querySelector('i');
    
    if (elemento && icono) {
        const esPositivo = variacion >= 0;
        const esBalance = tipo === 'balance';
        
        // Actualizar icono
        if (esBalance) {
            icono.className = esPositivo ? 'fas fa-arrow-up' : 'fas fa-arrow-down';
        }
        
        // Actualizar texto y color
        if (variacion === 0) {
            elemento.textContent = '0%';
            elemento.style.color = '';
        } else {
            const prefijo = esPositivo ? '+' : '';
            elemento.textContent = `${prefijo}${Math.abs(Math.round(variacion))}%`;
            
            if (esBalance) {
                elemento.style.color = esPositivo ? '#27AE60' : '#E74C3C';
            } else {
                elemento.style.color = esPositivo ? '#27AE60' : '#E74C3C';
            }
        }
    }
}

// Formatear fecha
function formatearFecha(fechaISO) {
    const opciones = { day: '2-digit', month: 'short', year: 'numeric' };
    return new Date(fechaISO).toLocaleDateString('es-ES', opciones);
}

// Formatear categoría
function formatearCategoria(categoria) {
    return categoria
        .split('-')
        .map(palabra => palabra.charAt(0).toUpperCase() + palabra.slice(1))
        .join(' ');
}

// Mostrar notificación
function mostrarNotificacion(mensaje, tipo) {
    // Implementar notificaciones bonitas
    console.log(`[${tipo.toUpperCase()}] ${mensaje}`);
}

// Cargar movimientos desde localStorage
function cargarMovimientos() {
    const movimientosGuardados = localStorage.getItem('finanzas-movimientos');
    if (movimientosGuardados) {
        movimientos = JSON.parse(movimientosGuardados);
        
        // Cargar movimientos del mes actual
        const movimientosMes = obtenerMovimientosDelMes();
        actualizarListaMovimientos(movimientosMes);
    }
}

// Guardar movimientos en localStorage
function guardarMovimientos() {
    localStorage.setItem('finanzas-movimientos', JSON.stringify(movimientos));
}

// Inicializar categorías en el filtro
function inicializarCategoriasFiltro() {
    const categorias = [
        'ventas', 'ingresos-extras', 'materia-prima', 
        'servicios', 'alquiler', 'sueldos', 'otros'
    ];
    
    const selectCategoria = document.getElementById('categoria');
    const selectFiltroCategoria = document.getElementById('filtro-categoria');
    
    // Limpiar opciones existentes
    selectCategoria.innerHTML = '<option value="">Selecciona una categoría</option>';
    selectFiltroCategoria.innerHTML = '<option value="">Todas las categorías</option>';
    
    // Agregar categorías a ambos selectores
    categorias.forEach(categoria => {
        const nombreFormateado = formatearCategoria(categoria);
        
        // Selector de formulario
        const opcion = document.createElement('option');
        opcion.value = categoria;
        opcion.textContent = nombreFormateado;
        selectCategoria.appendChild(opcion);
        
        // Selector de filtro
        const opcionFiltro = document.createElement('option');
        opcionFiltro.value = categoria;
        opcionFiltro.textContent = nombreFormateado;
        selectFiltroCategoria.appendChild(opcionFiltro);
    });
}

// Inicializar la aplicación
function inicializar() {
    // Configurar fecha actual en el formulario
    document.getElementById('fecha').value = new Date().toISOString().split('T')[0];
    
    // Inicializar categorías
    inicializarCategoriasFiltro();
    
    // Cargar datos guardados
    cargarMovimientos();
    
    // Actualizar interfaz
    actualizarFecha();
    actualizarResumen();
    actualizarGraficos();
}

// Iniciar la aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', inicializar);
